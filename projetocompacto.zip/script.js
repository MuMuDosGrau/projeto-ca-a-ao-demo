const form = document.querySelector('form')
const foto = document.getElementById('foto')
const nome = document.getElementById('nome')
const classe = document.getElementById('classe')
const descricao = document.getElementById('descricao')
let naoEncontrou = true

//Vetor de duas dimensões para armazenar as informações dos fantasmas:
const fantasmas = [
    ['37', 'Slimer', 'Slimer é um fantasma inofensivo, amigável, mas guloso (exceto no episódio piloto) que quer ajudar os Caça-Fantasmas. Ele também adora comida, o que o coloca em apuros no início da série The Real Ghostbusters. Na época, Egon especulou que Slimer comeu por causa do desejo de ser aceito pelos Caça-Fantasmas.', 'https://i.gifer.com/VU0J.gif', 'Classe 5'],
    ['22', 'Stay Puft Marshmallow Man', 'O Stay Puft Marshmallow Man era inicialmente uma entidade aparentemente hostil, provavelmente devido a quando era uma forma destruidora para Gozer. Começando em " The Revenge of Murray the Mantis ", Stay Puft se tornou um gigante gentil que parece respeitar e gostar dos Caça-Fantasmas, a ponto de uma vez afirmar que todos eles são seus amigos. Ele pode ser muito amigo das crianças, como mostrado em "Sticky Business", mas ainda é um espírito livre.', 'https://img.buzzfeed.com/buzzfeed-static/static/2015-10/15/12/enhanced/webdr06/anigif_original-grid-image-25013-1444925441-1.gif?crop=205:205;172,-1', 'Classe 10'],
    ['14', 'Gozer', 'Como visto no comportamento violento de Gozer quando confrontado pelos Caça-Fantasmas, Gozer é um ser frio, implacável e divino, que não tem escrúpulos em matar aqueles que considera inferiores. Sua reação à resposta contundente de Ray Stantz a ele perguntando se ele era um deus também mostra que ele despreza os seres mortais, vendo-os como não vale a pena se preocupar. Como pode ser visto em sua resposta agressiva aos Caça-Fantasmas que o atacam, ele também tem uma tendência a atacar sempre que provocado. Conforme indicado por seu monólogo antes de sua transformação, é livresco e excessivamente dramático em seus maneirismos. Em uma entrevista, Slavitza Jovan descreveu Gozer como sendo "quase arrogante", bem como "vendo os humanos como estando abaixo dela".', 'https://i.gifer.com/lln.gif', 'Classe 7'],
    ['26', 'Mastigador', 'Embora tenha sido apelidado de "Muncher", pode-se argumentar que "devorar por atacado" pode ser um título mais homônimo. O maior apetite de todos os Glutões que já observei! Embora Muncher tenha a capacidade de comer várias toneladas de resíduos inanimados, é mostrada uma preferência única por objetos de natureza metálica que fornecem aos Munchers um "inchaço" bônus, uma frase que nunca acreditei que um intelectual, como eu, teria que escrever. . Quando Muncher está cheio, ele pode reformar esse refugo em pequenos grânulos de força destrutiva.', 'https://midias.correiobraziliense.com.br/_midias/jpg/2021/11/15/675x450/1_image_1_-7060961.jpg?20211117173831?20211117173831', 'Classe 5'],
    ['15', 'Mini-Puffs', 'Mini-Pufts podem parecer fofos, mas são bastante destrutivos. Eles tendem a não pensar antes de agir e não se importam com o bem-estar uns dos outros.', 'https://media.tenor.com/xCqcnxG9lbQAAAAC/hug-me-ghostbusters-afterlife.gif', 'Classe 5']
]

//Função para limpar a mensagem:
function limparMensagem(naoEncontrou = true) {
    if (naoEncontrou) {
        mensagemEstilo.clearRect(0, 0, canvas.width, canvas.height)
    }
    return alert(`Fantasma Encontrado!!!
Deseja Continuar?`)
}

form.onsubmit = (evento) => {
    const inputs = new FormData(evento.target)
    const temperatura = inputs.get('temperatura').toUpperCase()
    let encontrouFantasma = false

    for (let i = 0; i < fantasmas.length; i++) {
        if (temperatura == fantasmas[i][0].toUpperCase()) {
            nome.textContent = fantasmas[i][1]
            descricao.textContent = fantasmas[i][2]
            foto.src = fantasmas[i][3]
            classe.textContent = fantasmas[i][4]
            encontrouFantasma = true
        }
    }

    if (!encontrouFantasma) {
        desenharMensagem()
    } else {
        limparMensagem(true)
    }
    return false
}

const canvas = document.getElementById('mensagem');
//Fazer a frase ser imprimida no plano 2D
const mensagemEstilo = canvas.getContext('2d');

//Estilização da mensagem:
const mensagem = 'Nenhum Fantasma Detectado!';
const fontSize = 24;
const x = canvas.width / 2;
const y = canvas.height / 2;

//Função para desenhar a mensagem:
function desenharMensagem() {

    mensagemEstilo.font = `${fontSize}px Arial`;
    mensagemEstilo.fillStyle = 'red';
    mensagemEstilo.textAlign = 'center';
    mensagemEstilo.textBaseline = 'middle';
    mensagemEstilo.fillText(mensagem, x, y);

}

